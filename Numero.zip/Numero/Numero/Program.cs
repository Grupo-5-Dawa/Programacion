﻿using System;

namespace ConsoleProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menú");
            Console.WriteLine("1. Calcular si un número es primo");
            Console.WriteLine("2. Calcular el factorial");
            Console.WriteLine("3. Dado un número en segundos, devolver horas y minutos");
            Console.WriteLine("4. Devolver los primeros 15 números de la serie de Pell");
            Console.WriteLine("5. Devolver si un número es un número de Armstrong o no");
            Console.WriteLine("6. Devolver si un número tiene todos sus dígitos diferentes");
            Console.WriteLine("Elige una opción (1-6):");

            int opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese un número: ");
                    int num1 = int.Parse(Console.ReadLine());
                    bool esPrimo = true;

                    for (int i = 2; i < num1; i++)
                    {
                        if (num1 % i == 0)
                        {
                            esPrimo = false;
                            break;
                        }
                    }

                    if (esPrimo)
                        Console.WriteLine("El número es primo");
                    else
                        Console.WriteLine("El número no es primo");

                    Console.ReadKey();
                    break;
                case 2:
                    Console.WriteLine("Introduce un número para calcular su factorial: ");
                    int num2 = Convert.ToInt32(Console.ReadLine());

                    int factorial = 1;
                    for (int i = 1; i <= num2; i++)
                    {
                        factorial *= i;
                    }

                    Console.WriteLine($"El factorial de {num2} es {factorial}");
                    break;
                case 3:
                    Console.WriteLine("Introduce el número de segundos: ");
                    int SegundosTotales = Convert.ToInt32(Console.ReadLine());

                    int Horas = SegundosTotales / 3600;
                    int Minutos = (SegundosTotales % 3600) / 60;
                    int Segundos = SegundosTotales % 60;

                    Console.WriteLine($"{Horas} horas, {Minutos} minutos y {Segundos} segundos");
                    break;
                case 4:
                    Console.WriteLine("Los primeros 15 números de la serie de Pell son: ");

                    int a = 0, b = 1;
                    for (int i = 0; i < 15; i++)
                    {
                        int c = 2 * b + a;
                        a = b;
                        b = c;
                        Console.WriteLine(c);
                    }
                        break;
                case 5:
                    Console.WriteLine("Introduce un número para comprobar si es un número de Armstrong: ");
                    int numero = Convert.ToInt32(Console.ReadLine());

                    int numeroOriginal, residuo, resultado = 0;
                    numeroOriginal = numero;

                    int digitos = (int)Math.Floor(Math.Log10(numero) + 1);

                    while (numeroOriginal != 0)
                    {
                        residuo = numeroOriginal % 10;
                        resultado += (int)Math.Pow(residuo, digitos);
                        numeroOriginal /= 10;
                    }

                    if (resultado == numero)
                    {
                        Console.WriteLine($"{numero} es un número de Armstrong");
                    }
                    else
                    {
                        Console.WriteLine($"{numero} no es un número de Armstrong");
                    }
                    break;
                case 6:
                    Console.WriteLine("Introduce un número para comprobar si todos sus dígitos son diferentes: ");
                    int numero1 = Convert.ToInt32(Console.ReadLine());

                    int[] digitos1 = numero1.ToString().Select(x => x - '0').ToArray();
                    bool sonDiferentes = digitos1.Distinct().Count() == digitos1.Length;

                    if (sonDiferentes)
                    {
                        Console.WriteLine($"{numero1} tiene todos sus dígitos diferentes");
                    }
                    else
                    {
                        Console.WriteLine($"{numero1} no tiene todos sus dígitos diferentes");
                    }
                    break;
            }
        }
    }
}
